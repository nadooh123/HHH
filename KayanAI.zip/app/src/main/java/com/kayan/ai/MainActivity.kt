package com.kayan.ai

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Bundle
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

private enum class Mode(val title: String) { CHAT("محادثة"), IMAGE("صورة"), VIDEO("فيديو"), SPEAK("قراءة صوتية") }
private data class Message(val role: String, val text: String)
private data class OutputFile(val file: File, val mime: String, val name: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale("ar")
        }
        val prefs = getSharedPreferences("kayan_settings", MODE_PRIVATE)
        setContent {
            KayanScreen(
                initialChatUrl = prefs.getString("chat_url", "") ?: "",
                initialChatKey = prefs.getString("chat_key", "") ?: "",
                initialModel = prefs.getString("chat_model", "") ?: "",
                initialComfyUrl = prefs.getString("comfy_url", "") ?: "",
                initialImageWorkflow = prefs.getString("image_workflow", "") ?: "",
                initialVideoWorkflow = prefs.getString("video_workflow", "") ?: "",
                onSaveSettings = { chatUrl, key, model, comfyUrl, imageWorkflow, videoWorkflow ->
                    prefs.edit()
                        .putString("chat_url", chatUrl)
                        .putString("chat_key", key)
                        .putString("chat_model", model)
                        .putString("comfy_url", comfyUrl)
                        .putString("image_workflow", imageWorkflow)
                        .putString("video_workflow", videoWorkflow)
                        .apply()
                },
                onSpeak = { text ->
                    if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kayan-tts")
                },
                onSaveOutput = { output -> saveToDownloads(this, output) }
            )
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}

@Composable
private fun KayanScreen(
    initialChatUrl: String,
    initialChatKey: String,
    initialModel: String,
    initialComfyUrl: String,
    initialImageWorkflow: String,
    initialVideoWorkflow: String,
    onSaveSettings: (String, String, String, String, String, String) -> Unit,
    onSpeak: (String) -> Unit,
    onSaveOutput: (OutputFile) -> Uri?
) {
    var mode by remember { mutableStateOf(Mode.CHAT) }
    var prompt by remember { mutableStateOf("") }
    var chatUrl by remember { mutableStateOf(initialChatUrl) }
    var chatKey by remember { mutableStateOf(initialChatKey) }
    var model by remember { mutableStateOf(initialModel) }
    var comfyUrl by remember { mutableStateOf(initialComfyUrl) }
    var imageWorkflow by remember { mutableStateOf(initialImageWorkflow) }
    var videoWorkflow by remember { mutableStateOf(initialVideoWorkflow) }
    var showSettings by remember { mutableStateOf(initialChatUrl.isBlank() || initialComfyUrl.isBlank()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("ابدأ بإعداد مزود المحادثة أو خادم ComfyUI من الإعدادات") }
    var output by remember { mutableStateOf<OutputFile?>(null) }
    val messages = remember { mutableStateListOf<Message>() }
    val scope = rememberCoroutineScope()
    val bg = Color(0xFF0B1020)
    val panel = Color(0xFF17243A)
    val accent = Color(0xFF5EEAD4)

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, background = bg, surface = panel)) {
        Column(Modifier.fillMaxSize().background(bg).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Kayan AI", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("مساعد مفتوح المصدر متعدد الوسائط", color = Color(0xFF9CB0CA), fontSize = 12.sp)
                }
                TextButton(onClick = { showSettings = !showSettings }) { Text("الإعدادات") }
            }
            if (showSettings) {
                Surface(color = panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().weight(1.4f, fill = false)) {
                    LazyColumn(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        item { Text("إعداد الاتصال", color = Color.White, fontWeight = FontWeight.Bold) }
                        item { SettingField("رابط Chat Completions المتوافق مع OpenAI", chatUrl, { chatUrl = it }, "مثال: https://server.example/v1/chat/completions") }
                        item {
                            OutlinedTextField(value = chatKey, onValueChange = { chatKey = it }, modifier = Modifier.fillMaxWidth(), label = { Text("مفتاح API (اختياري حسب الخادم)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                        }
                        item { SettingField("اسم نموذج المحادثة", model, { model = it }, "مثال: model-name") }
                        item { SettingField("رابط خادم ComfyUI", comfyUrl, { comfyUrl = it }, "مثال: http://192.168.1.5:8188") }
                        item { Text("سير عمل الصور بصيغة API JSON", color = Color.White, fontWeight = FontWeight.SemiBold) }
                        item { OutlinedTextField(value = imageWorkflow, onValueChange = { imageWorkflow = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp), placeholder = { Text("الصق ملف workflow API من ComfyUI") }, minLines = 3, maxLines = 5) }
                        item { Text("سير عمل الفيديو بصيغة API JSON", color = Color.White, fontWeight = FontWeight.SemiBold) }
                        item { OutlinedTextField(value = videoWorkflow, onValueChange = { videoWorkflow = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 90.dp), placeholder = { Text("الصق سير عمل فيديو متوافقاً مع ComfyUI") }, minLines = 3, maxLines = 5) }
                        item {
                            Button(onClick = {
                                onSaveSettings(chatUrl.trim(), chatKey.trim(), model.trim(), comfyUrl.trim(), imageWorkflow, videoWorkflow)
                                showSettings = false
                                status = "حُفظت الإعدادات على الجهاز"
                            }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الإعدادات") }
                        }
                        item { Text("ملاحظة: التطبيق لا يوفّر خادماً مجانياً. يلزم خادمك الخاص أو مزود تختاره. لا تضع مفتاحاً سرياً في نسخة APK عامة.", color = Color(0xFFFFD28A), fontSize = 11.sp) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                Mode.values().forEach { item ->
                    FilterChip(selected = mode == item, enabled = !busy, onClick = {
                        mode = item
                        output?.file?.delete()
                        output = null
                    }, label = { Text(item.title, fontSize = 10.sp) })
                }
            }
            Spacer(Modifier.height(8.dp))
            Surface(color = panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f).fillMaxWidth()) {
                when (mode) {
                    Mode.CHAT -> {
                        if (messages.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("اكتب سؤالك لبدء المحادثة", color = Color(0xFF9CB0CA), fontSize = 17.sp)
                        } else LazyColumn(Modifier.fillMaxSize().padding(9.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(messages) { msg ->
                                Surface(color = if (msg.role == "user") Color(0xFF164E63) else Color(0xFF263650), shape = RoundedCornerShape(11.dp), modifier = Modifier.fillMaxWidth()) {
                                    Text((if (msg.role == "user") "أنت: " else "Kayan: ") + msg.text, color = Color.White, modifier = Modifier.padding(10.dp))
                                }
                            }
                        }
                    }
                    Mode.SPEAK -> Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("🔊", fontSize = 42.sp)
                        Text("قراءة النص بصوت عربي", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("تستخدم هذه الميزة محرك تحويل النص إلى كلام المثبت في هاتفك، وقد تختلف الأصوات حسب الجهاز.", color = Color(0xFF9CB0CA), fontSize = 12.sp)
                    }
                    Mode.IMAGE, Mode.VIDEO -> Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(if (mode == Mode.IMAGE) "🎨" else "🎬", fontSize = 42.sp)
                        Text(if (mode == Mode.IMAGE) "إنشاء صورة عبر ComfyUI" else "إنشاء فيديو عبر ComfyUI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("يُرسل التطبيق الوصف إلى سير العمل الذي أعددته في ComfyUI. قدرات التوليد تعتمد على النماذج والخادم.", color = Color(0xFF9CB0CA), fontSize = 12.sp)
                        output?.let { file ->
                            Spacer(Modifier.height(12.dp))
                            Text("تم استلام الملف: ${file.name}", color = accent)
                            Button(enabled = !busy, onClick = {
                                scope.launch {
                                    busy = true
                                    status = "جارٍ حفظ الملف..."
                                    try {
                                        val saved = withContext(Dispatchers.IO) { onSaveOutput(file) }
                                        status = if (saved != null) {
                                            if (Build.VERSION.SDK_INT >= 29) "تم الحفظ في Download/KayanAI"
                                            else "تم الحفظ في مجلد تنزيلات التطبيق الخاص؛ قد لا يظهر في تطبيق الملفات العام"
                                        } else "تعذر حفظ الملف"
                                    } catch (e: Exception) {
                                        status = e.message ?: "تعذر حفظ الملف"
                                    } finally { busy = false }
                                }
                            }) { Text("حفظ في الهاتف") }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text(when (mode) { Mode.CHAT -> "اكتب سؤالك..."; Mode.IMAGE -> "صف الصورة..."; Mode.VIDEO -> "صف الفيديو..."; Mode.SPEAK -> "اكتب النص الذي تريد سماعه..." }) },
                minLines = 2, maxLines = 4
            )
            Spacer(Modifier.height(7.dp))
            Button(
                enabled = !busy && prompt.isNotBlank(),
                onClick = {
                    val text = prompt.trim()
                    prompt = ""
                    if (mode == Mode.SPEAK) {
                        onSpeak(text)
                        status = "إذا لم تسمع صوتاً، تحقق من تثبيت محرك تحويل النص إلى كلام واللغة العربية في إعدادات الهاتف."
                    } else {
                        val requestMode = mode
                        busy = true
                        if (requestMode == Mode.CHAT) messages.add(Message("user", text))
                        val chatHistory = if (requestMode == Mode.CHAT) messages.toList() else emptyList()
                        val requestChatUrl = chatUrl
                        val requestChatKey = chatKey
                        val requestModel = model
                        val requestComfyUrl = comfyUrl
                        val requestWorkflow = if (requestMode == Mode.IMAGE) imageWorkflow else videoWorkflow
                        status = "جارٍ التنفيذ..."
                        scope.launch {
                            try {
                                when (requestMode) {
                                    Mode.CHAT -> {
                                        val answer = withContext(Dispatchers.IO) { chatRequest(requestChatUrl, requestChatKey, requestModel, chatHistory) }
                                        messages.add(Message("assistant", answer))
                                        status = "اكتملت الإجابة"
                                    }
                                    Mode.IMAGE, Mode.VIDEO -> {
                                        val result = withContext(Dispatchers.IO) { runComfyWorkflow(requestComfyUrl, requestWorkflow, text, requestMode == Mode.VIDEO) }
                                        output?.file?.delete()
                                        output = result
                                        status = "اكتمل التوليد: ${result.name}"
                                    }
                                    else -> Unit
                                }
                            } catch (e: Exception) {
                                status = e.message ?: "حدث خطأ غير معروف"
                            } finally { busy = false }
                        }
                    }
                }, modifier = Modifier.fillMaxWidth()
            ) { Text(if (busy) "جارٍ العمل..." else when (mode) { Mode.CHAT -> "إرسال"; Mode.IMAGE -> "إنشاء صورة"; Mode.VIDEO -> "إنشاء فيديو"; Mode.SPEAK -> "تشغيل الصوت" }) }
            Text(status, color = if (status.contains("خطأ") || status.contains("تعذر")) Color(0xFFFFA0A0) else Color(0xFF9CB0CA), fontSize = 11.sp, modifier = Modifier.padding(top = 5.dp))
        }
    }
}

@Composable
private fun SettingField(label: String, value: String, onChange: (String) -> Unit, hint: String) {
    OutlinedTextField(value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth(), label = { Text(label) }, placeholder = { Text(hint) }, singleLine = true)
}

private fun chatRequest(endpoint: String, key: String, model: String, history: List<Message>): String {
    require(endpoint.startsWith("https://") || endpoint.startsWith("http://")) { "أدخل رابط Chat Completions صحيحاً في الإعدادات" }
    require(model.isNotBlank()) { "أدخل اسم نموذج المحادثة في الإعدادات" }
    val msgs = JSONArray()
    history.takeLast(24).forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
    val body = JSONObject().put("model", model).put("messages", msgs)
    val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"; connectTimeout = 20000; readTimeout = 90000; doOutput = true
        setRequestProperty("Content-Type", "application/json")
        if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer $key")
    }
    try {
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("فشل الخادم ($code): ${extractError(raw)}")
        val root = JSONObject(raw)
        return root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")
            ?.takeIf { it.isNotBlank() } ?: throw IllegalStateException("لم يرجع الخادم نص إجابة متوافقاً مع OpenAI API")
    } finally { conn.disconnect() }
}

private fun runComfyWorkflow(baseUrl: String, workflowJson: String, userPrompt: String, video: Boolean): OutputFile {
    require(baseUrl.startsWith("http://") || baseUrl.startsWith("https://")) { "أدخل رابط خادم ComfyUI في الإعدادات" }
    require(workflowJson.isNotBlank()) { "ألصق سير عمل API الخاص بـ ComfyUI في الإعدادات أولاً" }
    val workflow = JSONObject(workflowJson)
    replacePromptTokens(workflow, userPrompt)
    val request = JSONObject().put("prompt", workflow)
    val base = baseUrl.trimEnd('/')
    val submit = httpJson(URL("$base/prompt"), request.toString())
    val promptId = submit.optString("prompt_id")
    require(promptId.isNotBlank()) { "لم يُرجع ComfyUI معرف المهمة. تحقق من صيغة API workflow" }

    var history: JSONObject? = null
    for (attempt in 0 until 300) {
        Thread.sleep(2000)
        val h = httpGetJson(URL("$base/history/$promptId"))
        history = h.optJSONObject(promptId) ?: h.optJSONObject("history")?.optJSONObject(promptId)
        val status = history?.optJSONObject("status")
        if (status?.optString("status_str") == "error") {
            throw IllegalStateException("فشل تنفيذ workflow في ComfyUI. راجع سجل الخادم وتأكد من النماذج والعقد المطلوبة")
        }
        if (history != null && history!!.has("outputs")) break
    }
    val result = history ?: throw IllegalStateException("انتهت مهلة الانتظار. تحقق من حالة خادم ComfyUI")
    val outputs = result.optJSONObject("outputs") ?: throw IllegalStateException("انتهت المهمة دون مخرجات. افحص سجل ComfyUI")
    var selected: JSONObject? = null
    var selectedType = ""
    val keys = outputs.keys()
    while (keys.hasNext()) {
        val node = outputs.optJSONObject(keys.next()) ?: continue
        val expectedFields = if (video) listOf("videos", "gifs") else listOf("images")
        for (field in expectedFields) {
            val arr = node.optJSONArray(field) ?: continue
            if (arr.length() > 0) { selected = arr.optJSONObject(0); selectedType = field; break }
        }
        if (selected != null) break
    }
    val item = selected ?: throw IllegalStateException(
        if (video) "لم يُرجع workflow ملف فيديو. تأكد أنه ينتج مخرجاً ضمن videos أو gifs"
        else "لم يُرجع workflow ملف صورة ضمن images"
    )
    val filename = item.optString("filename")
    require(filename.isNotBlank()) { "اسم الملف غير موجود في استجابة ComfyUI" }
    val subfolder = item.optString("subfolder", "")
    val type = item.optString("type", "output")
    val query = "filename=${enc(filename)}&subfolder=${enc(subfolder)}&type=${enc(type)}"
    val ext = filename.substringAfterLast('.', if (video || selectedType != "images") "mp4" else "png").lowercase()
    val mime = when (ext) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "mp4" -> "video/mp4"
        "webm" -> "video/webm"
        "mov" -> "video/quicktime"
        else -> throw IllegalStateException("صيغة الملف غير مدعومة: .$ext")
    }
    // Stream to disk instead of loading a potentially large video fully into RAM.
    val file = downloadToTempFile(URL("$base/view?$query"), ext)
    return OutputFile(file, mime, filename.substringAfterLast('/').substringAfterLast('\\'))
}

private fun replacePromptTokens(value: Any?, prompt: String) {
    when (value) {
        is JSONObject -> {
            val keys = value.keys()
            val all = mutableListOf<String>()
            while (keys.hasNext()) all.add(keys.next())
            all.forEach { key ->
                val child = value.opt(key)
                if (child is String) value.put(key, child.replace("{{PROMPT}}", prompt).replace("__PROMPT__", prompt))
                else replacePromptTokens(child, prompt)
            }
        }
        is JSONArray -> for (i in 0 until value.length()) {
            val child = value.opt(i)
            if (child is String) value.put(i, child.replace("{{PROMPT}}", prompt).replace("__PROMPT__", prompt))
            else replacePromptTokens(child, prompt)
        }
    }
}

private fun httpJson(url: URL, body: String): JSONObject {
    val c = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"; connectTimeout = 20000; readTimeout = 30000; doOutput = true
        setRequestProperty("Content-Type", "application/json")
    }
    try {
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("ComfyUI رفض الطلب ($code): ${extractError(raw)}")
        return JSONObject(raw)
    } finally { c.disconnect() }
}

private fun httpGetJson(url: URL): JSONObject = JSONObject(String(httpGetBytes(url), Charsets.UTF_8))

private fun httpGetBytes(url: URL): ByteArray {
    val c = (url.openConnection() as HttpURLConnection).apply {
        connectTimeout = 20000
        readTimeout = 30000
        instanceFollowRedirects = false
    }
    try {
        val code = c.responseCode
        if (code !in 200..299) {
            val err = c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            throw IllegalStateException("فشل طلب ComfyUI ($code): ${extractError(err)}")
        }
        return c.inputStream.use { it.readBytes() }
    } finally { c.disconnect() }
}

private fun downloadToTempFile(url: URL, extension: String): File {
    val c = (url.openConnection() as HttpURLConnection).apply {
        connectTimeout = 20000
        readTimeout = 180000
        instanceFollowRedirects = false
    }
    var file: File? = null
    try {
        val code = c.responseCode
        if (code !in 200..299) {
            val err = c.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            throw IllegalStateException("فشل تحميل الملف ($code): ${extractError(err)}")
        }
        val tempFile = File.createTempFile("kayan_output_", ".$extension")
        file = tempFile
        c.inputStream.use { input -> tempFile.outputStream().buffered().use { output -> input.copyTo(output) } }
        if (tempFile.length() == 0L) throw IllegalStateException("الملف الذي أعاده الخادم فارغ")
        return tempFile
    } catch (e: Exception) {
        file?.delete()
        throw e
    } finally { c.disconnect() }
}

private fun extractError(raw: String): String = try {
    val json = JSONObject(raw)
    json.optJSONObject("error")?.optString("message") ?: json.optString("message", raw.take(240))
} catch (_: Exception) { raw.take(240).ifBlank { "لا توجد تفاصيل" } }

private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

private fun saveToDownloads(context: Context, output: OutputFile): Uri? {
    var insertedUri: Uri? = null
    return try {
        require(output.file.exists() && output.file.length() > 0L) { "ملف النتيجة غير موجود أو فارغ" }
        if (Build.VERSION.SDK_INT < 29) {
            val downloadsRoot = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            val folder = File(downloadsRoot, "KayanAI")
            if (!folder.exists() && !folder.mkdirs()) throw IllegalStateException("تعذر إنشاء مجلد الحفظ")
            val legacyName = output.name.substringAfterLast('/').substringAfterLast('\\')
                .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "kayan_output" }
            val destination = File(folder, "${System.currentTimeMillis()}_$legacyName")
            output.file.copyTo(destination, overwrite = false)
            return Uri.fromFile(destination)
        }
        val safeName = output.name.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "kayan_output" }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
            put(MediaStore.MediaColumns.MIME_TYPE, output.mime)
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/KayanAI")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        val collection = if (output.mime.startsWith("video/")) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        insertedUri = context.contentResolver.insert(collection, values) ?: return null
        val stream = context.contentResolver.openOutputStream(insertedUri!!)
            ?: throw IllegalStateException("تعذر فتح ملف الحفظ")
        stream.use { out -> output.file.inputStream().use { it.copyTo(out) } }
        if (Build.VERSION.SDK_INT >= 29) {
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            context.contentResolver.update(insertedUri!!, done, null, null)
        }
        insertedUri
    } catch (_: Exception) {
        insertedUri?.let { runCatching { context.contentResolver.delete(it, null, null) } }
        null
    }
}
